function cluster_interactive_matlab_bash

   opt.Fs = 20;
   opt.video = false;
   folder = pwd;

   keyboard; % add breakpoint 
end