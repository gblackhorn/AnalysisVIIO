% Open matlab GUI by running:
%	bash open_matlab_with_display.sh

% Note: go to the folder containing recordings in its subfolders
%% ====================
% Run this section only once
addpath(genpath('/flash/UusisaariU/GD')); % add this folder to matlab path to use function in it and its subfolders
opt.Fs = 40;
opt.video = false;
folder = pwd; 

folder_content = dir(folder);
dirflag = [folder_content.isdir]; % Get a logical vector that tells which is a directory
subfolders = folder_content(dirflag); % Extract only those that are directories
subfolders = subfolders(~startsWith({subfolders.name}, '.')); % remove content starts with "."

subfolders_num = numel(subfolders); 
file_names = cell(subfolders_num, 1);

for i = 1:subfolders_num % Ignore "." and ".." 
	subfolder = fullfile(folder, subfolders(i).name);
	cnmfe_result_file = dir(fullfile(subfolder, '*results.mat'));
	if isempty(cnmfe_result_file)
        % List both .tif and .tiff files
        tiff_file_tif = dir(fullfile(subfolder, '*MC*.tif'));
        tiff_file_tiff = dir(fullfile(subfolder, '*MC*.tiff'));

        % Concatenate the results
        tiff_file = [tiff_file_tif; tiff_file_tiff];

        % discard deltaF/F file
		tiff_file = tiff_file(~contains({tiff_file.name}, '-dff', 'IgnoreCase', true)); 
		if length(tiff_file) > 1
			[~, idx] = sort([tiff_file.bytes], 'descend'); % sort files according to date
			[~, latest_file_idx] = max(idx);
			tiff_file = tiff_file(latest_file_idx); % use the latest modified file
        end
        file_names{i} = fullfile(subfolder, tiff_file.name);
	end
end
non_empty_idx = find(~cellfun(@isempty, file_names)); % index of cells not empty
file_names = file_names(non_empty_idx); % discard empty cells from "file_names"
file_num = numel(file_names);
disp([num2str(file_num), ' files will be processed:'])
disp(file_names)

ii = 1;
%% ====================
% run this section for each recordings.


if ii<=numel(file_names)
	nam = file_names{ii};
	fprintf('Recording %d/%d: %s\n',ii,numel(file_names),nam)
else
	fprintf('\nEnd of the subfolder list\n')
end
ii = ii+1;

% Temprol solution: pause at line 111 in "viewNeurons.m" make sure the ROI and traces will be plotted
% Note: pause at line 111 in "viewNeurons.m" to make sure that the ROI and
% traces will be plotted for manual selection


%% ====================
% cnmfe_process_batch_cluster('folder', folder,...
% 	'Fs', opt.Fs, 'video', opt.video);