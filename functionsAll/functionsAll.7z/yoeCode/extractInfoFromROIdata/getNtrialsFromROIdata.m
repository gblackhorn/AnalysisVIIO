function nTrials = getNtrialsFromROIdata(ROIdata)

[nTrials nInfo] = size(ROIdata);