[meanTrigFractionInGroup meanTrigFractionsInTrialsAP semTrigFractionsInTrialsAP trigFractions] = trigSpikeReliabilityInGroup(ROIdata_AP, 10, 100, 10);
[meanTrigFractionInGroup meanTrigFractionsInTrialsOG5 semTrigFractionsInTrialsOG5 trigFractions] = trigSpikeReliabilityInGroup(ROIdata_OGLED5, 10, 100, 10);
[meanTrigFractionInGroup meanTrigFractionsInTrialsOG10 semTrigFractionsInTrialsOG10 trigFractions] = trigSpikeReliabilityInGroup(ROIdata_OGLED10_selected, 10, 100, 10);
